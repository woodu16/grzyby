# Nie zbieromy w niedziela grzybów — modernizacja

## Wdrożenie na GitHub Pages
1. Otwórz repozytorium, z którego publikowana jest strona `woodu16.github.io/grzyby/`.
2. Otwórz plik `index.html` w katalogu publikacji (najczęściej katalog główny repozytorium).
3. Zastąp jego zawartość plikiem `index.html` z tej paczki.
4. Zapisz zmiany przez **Commit changes**.
5. Po zakończeniu publikacji odśwież stronę. GitHub Pages może potrzebować kilku minut.

## Konfiguracja godziny wyprawy
W pliku `index.html` znajdź:
`const TARGET_HOUR = 7;`
`const TARGET_MINUTE = 0;`
Zmień wartości, jeśli wyjście ma się zaczynać o innej godzinie. Licznik automatycznie wskazuje najbliższą niedzielę o tej godzinie.

## Dźwięki
Dźwięk jest generowany lokalnie przez przeglądarkę (szum wiatru i syntetyczne trele ptaków). Przeglądarki wymagają kliknięcia przycisku, zanim odtworzą dźwięk. Nic nie odtwarza się automatycznie.

Strona jest samodzielnym plikiem HTML. Zdjęcie tła i fonty są pobierane z zewnętrznych serwisów, więc do ich wyświetlenia potrzebne jest połączenie z internetem.
